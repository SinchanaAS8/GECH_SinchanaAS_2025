package springboot.java;

public class Employee {
    public int empID;
    public String empName;
    public Employee(int empID, String empName) {
        this.empID = empID;
        this.empName = empName;
    }

}
