package com.FormValidation.FormValidation.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.FormValidation.FormValidation.dto.StudentDTO;
import com.FormValidation.FormValidation.model.Student;
import com.FormValidation.FormValidation.repository.StudentRepository;
import com.FormValidation.FormValidation.service.StudentService;

import jakarta.validation.Valid;
//import org.springframework.web.bind.annotation.RestController;


@Controller
public class HomeController {
	
	private final StudentService studentService;
	private final StudentRepository studentRepository;
	// Constructor Injection
	@Autowired
	
//	public HomeController(StudentService studentService) {
//		super();
//		this.studentService = studentService;
//	}
	public HomeController(StudentService studentService, StudentRepository studentRepository) {
		super();
		this.studentService = studentService;
		this.studentRepository = studentRepository;
	}
	
	@GetMapping("/add-student")
	public String addStudent(Model model) {
		model.addAttribute("studentDTO", new StudentDTO());
		return "add_student";
	}
	
	@GetMapping("/")
	public String listStudents(Model model) {
	    List<Student> students = studentService.getAllstudents();
	    model.addAttribute("students", students);
	    return "home";
	}

		
	@PostMapping("/add-student")
	public String addStudent(@Valid @ModelAttribute StudentDTO studentDTO, BindingResult result, Model model) {
		if(result.hasErrors()) {
			return "add_student";
		}
		
		System.out.println(studentDTO.getName());
		studentService.saveStudent(studentDTO);
		return "redirect:/";	
	}
	@GetMapping("/std-delete")
	public String deleteStudent(@RequestParam Long id) {
		studentService.deleteStudent(id);
		return "redirect:/";
	}
	@GetMapping("/std-edit")
	public String editStudent(@RequestParam Long id, Model model) {
		StudentDTO studentDTO = studentService.editStudent(id);
		Student student = studentRepository.findById(id).get();
		model.addAttribute("studentDTO", studentDTO);
		model.addAttribute("student", student);
		return "edit_student";
	}
	
	@PostMapping("/edit-student")
	public String updateStudent(@Valid @ModelAttribute StudentDTO studentDTO,BindingResult result,@RequestParam Long id,Model model ) {
		if(result.hasErrors()) {
			Student student=studentRepository.findById(id).get();
			 model.addAttribute("student",student);
			return "edit_student";
		}
		studentService.updateStudent(studentDTO,id);
	 return "redirect:/";

    }
}
